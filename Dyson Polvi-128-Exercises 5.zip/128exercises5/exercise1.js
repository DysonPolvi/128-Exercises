let userIntOne = parseInt(prompt("Please enter a first number"));
let userIntTwo = parseInt(prompt("Please enter a second number"));

function biggest(userIntOne, userIntTwo) {
    if (userIntOne > userIntTwo) {
        document.querySelector("#div1").innerHTML = userIntOne;
    } else if (userIntOne < userIntTwo) {
        document.querySelector("#div1").innerHTML = userIntTwo;
    } else if (userIntOne == userIntTwo) {
        document.querySelector("#div1").innerHTML = `${userIntOne} is equal to ${userIntTwo}`
    } else document.querySelector("#div1").innerHTML = "please enter a valid number";
}

biggest(userIntOne, userIntTwo);