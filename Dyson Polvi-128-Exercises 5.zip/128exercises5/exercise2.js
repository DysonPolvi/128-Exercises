let userString = prompt("Please enter a string of text");
let userStringNumber =  parseInt(prompt("What is the position of the character you would like to pull"));

function findIt(userString, userStringNumber) {
    console.log("this is working");
    userCharPosition = userString.substring(userStringNumber-1, userStringNumber);
    return userCharPosition;
}

let userCharPosition = findIt(userString, userStringNumber);
document.querySelector("#div2").innerHTML = userCharPosition;