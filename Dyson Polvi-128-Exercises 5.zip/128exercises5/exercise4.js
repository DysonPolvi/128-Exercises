let userDollars = parseFloat(prompt("Please enter a dollar amount"));
let userROI = (parseFloat(prompt("Please enter an investment rate"))/100);

let userTotal = (userDollars, userROI) => {document.querySelector("#div4").innerHTML = userDollars+(userDollars*userROI)};

userTotal(userDollars, userROI);