let userLongString = prompt("Please enter a long string");
let userLetter = prompt("Please enter the letter whose occurances you would like to count");

function instanceFinder(userLongString, userLetter) {
    let userInstances = 0;
    for (let i = 0; i < userLongString.length; i++) {
        if (userLongString[i] == userLetter) {
            userInstances++;
        }
    }
    return userInstances;
}
userInstances = instanceFinder(userLongString, userLetter);
document.querySelector("#div3").innerHTML = userInstances;