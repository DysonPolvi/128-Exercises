let button = document.querySelector("#btn"); 
let divs = document.querySelectorAll(".div-id");
// let text2 = document.querySelector(".div-id");
// let text3 = document.querySelector(".div-id");

for (let i = 2; i < divs.length; i++) {
button.addEventListener('click', function textColours() {
    divs[i].style.backgroundColor = "yellow";
    divs[i].style.color = "blue";
    divs[i].style.fontWeight = "bold";
});
}