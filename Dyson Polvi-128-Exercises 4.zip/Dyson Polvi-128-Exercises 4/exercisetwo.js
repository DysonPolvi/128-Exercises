let awesomeText2 = document.querySelector("#div2-id");
awesomeText2.addEventListener("mouseover", function awesomeHover2() {
    awesomeText2.innerHTML = "I am very awesome";
});
awesomeText2.addEventListener("mouseout", function awesomeHover2() {
    awesomeText2.innerHTML = "exerciseTwo";
});