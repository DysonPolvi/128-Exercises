let awesomeText = document.querySelector("#div1-id");
awesomeText.addEventListener("mouseover", function awesomeHover() {
    awesomeText.innerHTML = "I am very awesome";
})