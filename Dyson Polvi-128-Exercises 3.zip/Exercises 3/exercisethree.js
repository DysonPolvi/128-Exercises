for (let i = 5; i > 0; i--) {
    console.log(i);
    document.querySelector("#div3-id").innerHTML += `${i} <br>`;
}