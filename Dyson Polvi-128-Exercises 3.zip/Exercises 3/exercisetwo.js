let userFooBar = parseInt(prompt("Please enter a number"));

if ((userFooBar % 15) == 0) {
    document.querySelector("#h2-id").innerHTML = "FooBar";
} else if ((userFooBar % 3) == 0) {
    document.querySelector("#h2-id").innerHTML = "Foo";
} else if ((userFooBar % 5) == 0) {
    document.querySelector("#h2-id").innerHTML = "Bar";
} else {
    document.querySelector("#h2-id").innerHTML = userFooBar;
}