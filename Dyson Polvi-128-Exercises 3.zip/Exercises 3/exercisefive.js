for (let i = 0; i < 5; i++) {
    for (let j = 0; j <= i; j++) {
    document.querySelector("#h5-id").innerHTML += "*";
    }
    document.querySelector("#h5-id").innerHTML += "<br>"
}