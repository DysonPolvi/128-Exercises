let userAge = parseInt(prompt("Please enter your age:"));

switch (true) {
    case (userAge < 20): 
        document.querySelector("#h1-id").innerHTML = "junior";
        break;
    case (userAge >= 20 && userAge <= 39):
        document.querySelector("#h1-id").innerHTML = "professional";
        break;
    case (userAge >= 40 && userAge <=64):
        document.querySelector("#h1-id").innerHTML = "masters";
        break;
    case (userAge >= 65):
        document.querySelector("#h1-id").innerHTML = "retired";
        break;
    default: "nothing found";
}