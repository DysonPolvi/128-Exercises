for (let i = 1; i < 6; i++) {
    console.log(i);
    document.querySelector("#div4-id").innerHTML += `${i} <br>`;
}