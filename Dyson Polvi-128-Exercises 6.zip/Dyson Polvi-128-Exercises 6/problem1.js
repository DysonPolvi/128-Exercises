let problem1 = document.querySelector("#problem1");
problem1.innerHTML = parseInt((Math.random()*10)+1);