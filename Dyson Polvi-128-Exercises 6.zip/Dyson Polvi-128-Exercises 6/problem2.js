let userNumber1 = parseInt(prompt("Please enter a first number"));
let userNumber2 = parseInt(prompt("Please enter a second number"));
let problem2 = document.querySelector("#problem2");
if (userNumber2 < userNumber1) {
    problem2.innerHTML = "The first number must be smaller than the second number";
} else {
    problem2.innerHTML = parseInt((Math.random()*(userNumber2+1-userNumber1))+userNumber1);
}