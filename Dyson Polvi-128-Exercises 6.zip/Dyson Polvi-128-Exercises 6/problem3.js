let date1 = new Date("10/11/2009");
let date2 = new Date("11/13/2014");

let problem3o1 = document.querySelector("#problem3o1");
let problem3o2 = document.querySelector("#problem3o2");

problem3o1.innerHTML = date1.toLocaleString("default", {month: "long"});
problem3o2.innerHTML = date2.toLocaleString("default", {month: "long"});