let userAge = parseInt(prompt("Please enter your age:"));
let drinkingAge = (userAge >= 19) ? "You can buy beer!" : "you cannot buy beer!";
document.querySelector("#h2-id").innerHTML = drinkingAge; 