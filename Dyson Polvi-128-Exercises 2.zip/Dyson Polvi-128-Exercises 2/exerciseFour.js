let userFooBar = parseInt(prompt("Please enter a number"));

if ((userFooBar % 15) == 0) {
    document.querySelector("#h4-id").innerHTML = "FooBar";
} else if ((userFooBar % 3) == 0) {
    document.querySelector("#h4-id").innerHTML = "Foo";
} else if ((userFooBar % 5) == 0) {
    document.querySelector("#h4-id").innerHTML = "Bar";
} else {
    document.querySelector("#h4-id").innerHTML = userFooBar;
}