let userString = prompt("Please enter a string:");
let userNumber = parseInt(prompt("Please enter a number:"));

console.log(userString == userNumber);
console.log(userString === userNumber);