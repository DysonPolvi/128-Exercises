let userNumberOne = parseInt(prompt("please enter a first number:"));
let userNumberTwo = parseInt(prompt("Please enter a second number:"));
if (userNumberOne != userNumberTwo) {
    let userSum = userNumberOne * userNumberTwo;
    document.querySelector("#h1-id").innerHTML = userSum;
} else if (userNumberOne == userNumberTwo) {
    let userSum = (userNumberOne * userNumberTwo) * 3;
    document.querySelector("#h1-id").innerHTML = userSum;
}

