let userExerciseTwo = prompt("Please enter a valid Canadian phone number");

function canadianPhoneNumber(userExerciseTwo) {
    let userExerciseTwoRegex = /^\+91-\d{3}-\d{3}-\d{4}$/gm;
    let userExerciseTwoResult = userExerciseTwoRegex.test(userExerciseTwo);
    return userExerciseTwoResult;
}

document.querySelector("#problem2").innerHTML = canadianPhoneNumber(userExerciseTwo);