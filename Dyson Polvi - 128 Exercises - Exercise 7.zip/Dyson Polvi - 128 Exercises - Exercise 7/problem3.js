let userExerciseThree = prompt("Please enter a valid Adanacan postal code");

function adanacValidator(userExerciseThree) {
    let userExerciseThreeRegex = /^([\d][ABCEGHJKLMNPRSTVXY][\d])[\s|-]?([ABCEGHJKLMNPRSTVWXYZ][\d][ABCEGHJKLMNPRSTVWXYZ])(\:\))$/i;
    let userExerciseThreeResult = userExerciseThreeRegex.test(userExerciseThree);
    return userExerciseThreeResult;
}

document.querySelector("#problem3").innerHTML = adanacValidator(userExerciseThree);
