let userExerciseFour = prompt("Please enter a string");

function vowelFinder (userExerciseFour) {
    let userExerciseFourRegex = /(?<!\w)y|[aeiou]/gi;
    let userExerciseFourResult = userExerciseFour.match(userExerciseFourRegex);
    return userExerciseFourResult.length;
}

document.querySelector("#problem4").innerHTML = vowelFinder(userExerciseFour);

