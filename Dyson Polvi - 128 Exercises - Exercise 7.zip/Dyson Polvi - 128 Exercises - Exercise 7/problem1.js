let userExerciseOneRegex = /([0-9])\w*/;
let userExerciseOne = prompt("Please enter a number");

function numberInString(userExerciseOne) {
    let userExerciseOneResult = userExerciseOneRegex.test(userExerciseOne);
    return userExerciseOneResult;
}

document.querySelector("#problem1").innerHTML = numberInString(userExerciseOne);